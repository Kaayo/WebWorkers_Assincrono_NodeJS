main();
//main();
//main();
//main();

async function main() {
    var workerpool = require('workerpool');

    // create a worker pool using an the asyncWorker. This worker contains
    // asynchronous functions.
    var pool = workerpool.pool(__dirname + '/worker_async.js');

    //Promise - Funciona!
    /*
    pool.proxy()
        .then(function (worker) {
        return worker.asyncFor();
        })
        .then(function (result) {
        console.log(result);
        })
        .catch(function (err) {
        console.error(err);
        })
        .then(function () {
        pool.terminate(); // terminate all workers when done
        });
    */

    //Async/Await - Funciona!
    try {
        //Retornar o Worker com seus respectivos métodos para variável 'worker'
        let worker = await pool.proxy();
        //Executa a função 'asyncFor' do Worker e retorna o valor para a variável 'retorno'
        //let retorno = await worker.asyncFor()
        //Executa a função 'asyncConsultaBD' do Worker e retorna o valor retornado do Banco de Dados para a variável 'retorno'
        let retorno = await worker.asyncConsultaBD(['VALIDA_USUARIO', ['Caio', '123']])
        //Exibe o valor retornado
        console.log('retorno ',retorno)
    } catch (error) {
        //Exibe o erro
        console.log('Erro: '+error) 
    } finally {
        //Finaliza o Worker
        pool.terminate()
        console.log('worker finalizado!')
    }
}