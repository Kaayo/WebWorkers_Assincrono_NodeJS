// This example worker runs asynchronous tasks. In practice, this could be
// interacting with a database or a web service. The asynchronous function
// returns a promise which resolves with the task's result.

var workerpool = require('workerpool');
let WebSocket = require('ws')
let crypto = require('crypto')
let algorithm = 'aes-256-gcm'; //Algoritmo de encriptografia
let password = '3zTvzr3p67VC61jmV54rIYu1545x4TlY'; //string anexada junto a encriptografia, para tornar mais seguro
let iv = '60iP0h6vJoEa';
let ws = ''

// an async function returning a promise
function asyncAdd (a, b) {
  return new Promise(function (resolve, reject) {
    setTimeout(function () {
      resolve(a + b);
    }, 1000);
  });
}

// an async function returning a promise
function asyncMultiply (a, b) {
  return new Promise(function (resolve, reject) {
    setTimeout(function () {
      resolve(a * b);
    }, 1000);
  });
}

function teste(){
    console.log('oi')
}

//Funciona! - Executa a chamada interna da função 'teste()' e retorna a promesa!
function asyncFor () {
    teste();

    return new Promise(function (resolve, reject) {
        let x = 0
        for (let index = 0; index < 1000000000; index++) {
            x = index   
        }
        resolve(x)
    });
  }


//Função para criptografar 'String' ou 'Objeto JSON'
////////////////////////////////////////////////////////////////////////
function encrypt(text) {
    var cipher = crypto.createCipheriv(algorithm, password, iv)
    var encrypted = cipher.update(text, 'utf8', 'hex')
    encrypted += cipher.final('hex');
    var tag = cipher.getAuthTag();
    
    //TESTE 1 - Funciona! 
    //Observação: retorna string criptografada
    //return encrypted
    
    
    //TESTE 2 - Funciona! 
    //Observação: retorna um objeto contendo os campos:
    //content (contendo a string criptografada) e
    //tag (contendo uma string em formato de Buffer)
    return {
      content: encrypted,
      tag: tag
    }; 
}

function decrypt(encrypted) {
    var decipher = crypto.createDecipheriv(algorithm, password, iv)
    decipher.setAuthTag(encrypted.tag);
    var dec = decipher.update(encrypted.content, 'hex', 'utf8')
    dec += decipher.final('utf8');
    return dec;
}


//Função responsável por descriptografas a string criptografada enviada pela API Cliente
function DESCRIPTOGRAFA_DADOS(DADOS_CRIPTOGRAFADOS){

    let dados_descriptografados = '';
 
    if (typeof DADOS_CRIPTOGRAFADOS === 'string') {
       //console.log('\n Função DESCRIPTOGRAFA_DADOS - "STRING" \n')
 
       //console.log('STRING: '+DADOS_CRIPTOGRAFADOS)
       
       let objeto =  JSON.parse(DADOS_CRIPTOGRAFADOS)
       //console.log('FUNC D_D - PASSO 1 \n',objeto)
        
       
        //Variável('bufferr') recebe o dado no formato JSON proveniente do objeto Interno('tag' - objeto.tag) presete no Objeto('objeto') 
        //convertido no tipo de dado 'Buffer'
        let bufferr =  Buffer.from(objeto.tag);
        //console.log('BUFFER ',bufferr)
 
        //Objeto interno('tag' - objeto.tag) recebe o dado do tipo 'Buffer' através da variável 'bufferr'.
        //Observação: O objeto interno 'tag - objeto.tag', deve receber o dado convertido em 'Buffer', caso contrário
        //não é possivel descriptografar a string criptograda enviada pela API Cliente
        objeto.tag =  bufferr;
        
        //Variável('dados_descriptografados') recebe como resultado da descriptografia da string criptografada,
        //um objeto JSON descriptografado e com suas informações acessíveis 
        dados_descriptografados = decrypt(objeto);
        //console.log('FUNC D_D - PASSO 2 \n',dados_descriptografados)
 
    }
 
    if (typeof DADOS_CRIPTOGRAFADOS === 'object') {
       
 
    //PASSO 1
       //console.log('\n Função DESCRIPTOGRAFA_DADOS - "OBJETO" \n')
            
       //Variável('objeto') recebe a string criptografada vinda da API Client
        //convertida em Objeto JSON
       //let objeto = await JSON.parse(JSON.parse(DADOS_CRIPTOGRAFADOS));
       let objeto =  JSON.parse(DADOS_CRIPTOGRAFADOS);
       //console.log('FUNC D_D - PASSO 1 \n',objeto)
        
       
        //Variável('bufferr') recebe o dado no formato JSON proveniente do objeto Interno('tag' - objeto.tag) presete no Objeto('objeto') 
        //convertido no tipo de dado 'Buffer'
        let bufferr =  Buffer.from(objeto.tag);
 
        //Objeto interno('tag' - objeto.tag) recebe o dado do tipo 'Buffer' através da variável 'bufferr'.
        //Observação: O objeto interno 'tag - objeto.tag', deve receber o dado convertido em 'Buffer', caso contrário
        //não é possivel descriptografar a string criptograda enviada pela API Cliente
        objeto.tag =  bufferr;
        
        //Variável('dados_descriptografados') recebe como resultado da descriptografia da string criptografada,
        //um objeto JSON descriptografado e com suas informações acessíveis 
        dados_descriptografados =  JSON.parse(decrypt(objeto));
        //console.log('FUNC D_D - PASSO 2 \n',dados_descriptografados)
 
    }
 
        //Retorna um objeto JSON legível e acessível
        return dados_descriptografados
       
};

// an async function returning a promise
function asyncConsultaBD (DADOS) {
    return new Promise(function (resolve, reject) {
         ws = new WebSocket('ws://localhost:8888');  
      //ws = new WebSocket('ws://192.168.1.103:8888');

        ws.onopen = function(){
            try {
               
               //Objeto JSON para ser criptografado
               let ObjetoDadosCriptografados = {
                  usuario: 'Caio',
                  senha: '123',
                  dados: DADOS
               }
               
               //Objeto contendo informações de identifcação e informações criptografadas para serem executadas pela API Servidor.
               //Esse objeto é enviado pela API cliente para a API server.
               let ObjetoDeEnvio = {
                  Identificacao: {
                        Usuario: 'Caio',
                        Senha: '123'
                  },
                  
                  Dados: {
                        criptografia: ObjetoDadosCriptografados
                  }
               };
               

               //Variável('ObjCriptografado') recebe o objeto JSON('ObjDeEnvio') criptografado
               let ObjCriptografado = encrypt(JSON.stringify(ObjetoDeEnvio));
               //console.log('1 ',ObjCriptografado)
               //Variável('StringCriptografada') recebe o objeto JSON criptografado('ObjCriptografado') convertido em String
               //Observação: A comunicação entre API Server-Client é feita entre envio e recebimento de strings!
               let StringCriptografada = JSON.stringify(ObjCriptografado) //Para enviar via scoket deve ser assim!
               //console.log('2 ',StringCriptografada)
               
               //TESTE - OK
               //console.log('String Criptografada enviada para API-SERVER \n'+StringCriptografada)

               //Socket atual do cliente envia a string criptografada para a API Server
               ws.send(StringCriptografada);
               //await ws.send('TESTE');
          
         } catch (error) {
            console.log('error api client: '+error)  
         }
        };


        ws.onmessage = function(msg){
         
            try {
               //console.log('Mensagem retornada pela API-SERVER ',msg.data)
               let data1 = DESCRIPTOGRAFA_DADOS(msg.data)
               //console.log('MENSAGEM DO SERVIDOR DESCRIPTOGRAFADA: ',data1)

               if (data1 === 'usuário não validado!') {
                  //alert('TESTE OK')
                  resolve({
                     return:{
                        resolve: true,
                        data1
                     }
                  })
               } else {
                  
                 // console.log('\n DADOS CRIPTOGRAFADOS RECEBIDOS DA API-SERVER: \n ', msg.data)
                  //TESTE 2 - FUNCIONA!
               //   let data = DESCRIPTOGRAFA_DADOS(msg.data)
                //  console.log('\n DADOS JÁ DESCRIPTOGRAFADOS \n ', data)

                  
                  if (data1 == 0) {
                     //console.log('SEM DADOS! \n',data1)
                     data1 = 'VAZIO'
                  }

                  resolve({
                     return:{
                        resolve: true,
                        data1
                     }
                  })                 
                  
               }
               } catch(error){
                  //console.log('ERRO \n', error)
               }    
         };


         ws.onerror = function(){
            //ws.onerror = await function(){
                //console.log('cliente com erro!')
               
               //return false 
               resolve({
                  return:{
                     resolve: false
                  }
               })     
               //TESTE - FUNCIONA!
               //WEBSOCKET.RESTABELECE_CONEXAO_COM_API()
      
            };
            
            ws.onclose = function(){
            //ws.onclose = await function(){
                //console.log('cliente desconectado!')
   
               //TESTE - FUNCIONA!
               //WEBSOCKET.RESTABELECE_CONEXAO_COM_API()
            };


    });
  }


// create a worker and register public functions
workerpool.worker({
  asyncAdd: asyncAdd,
  asyncMultiply: asyncMultiply,
  asyncFor: asyncFor,
  asyncConsultaBD: asyncConsultaBD
});

